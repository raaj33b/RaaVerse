import { useSyncExternalStore } from 'react';
import { store, OSState } from '../store/osStore';

export function useOS(): OSState {
  return useSyncExternalStore(
    (cb) => store.subscribe(cb),
    () => store.state
  );
}
