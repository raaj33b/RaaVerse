import { useRef, useState, useEffect, KeyboardEvent } from 'react';
import { useOS } from '../hooks/useOS';
import { store } from '../store/osStore';

export default function Terminal() {
  const state = useOS();
  const [input, setInput] = useState('');
  const [histIdx, setHistIdx] = useState(-1);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.terminalOutput]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      store.runCommand(input);
      setInput('');
      setHistIdx(-1);
    } else if (e.key === 'ArrowUp') {
      const h = state.terminalHistory;
      const next = Math.min(histIdx + 1, h.length - 1);
      setHistIdx(next);
      setInput(h[h.length - 1 - next] ?? '');
      e.preventDefault();
    } else if (e.key === 'ArrowDown') {
      const next = Math.max(histIdx - 1, -1);
      setHistIdx(next);
      setInput(next === -1 ? '' : state.terminalHistory[state.terminalHistory.length - 1 - next] ?? '');
      e.preventDefault();
    }
  };

  return (
    <div
      className="h-full flex flex-col bg-black font-mono text-xs text-green-300 p-2 overflow-hidden"
      onClick={() => inputRef.current?.focus()}
    >
      <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin">
        {state.terminalOutput.map((line, i) => (
          <div key={i} className={`leading-5 whitespace-pre-wrap ${line.startsWith('[OK]') ? 'text-green-400' : line.startsWith('[BOOT]') ? 'text-cyan-400' : line.startsWith('[SANDBOX]') ? 'text-yellow-400' : line.startsWith('[') ? 'text-orange-400' : line.includes('command not found') ? 'text-red-400' : 'text-green-300'}`}>
            {line || '\u00A0'}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="flex items-center gap-1 border-t border-green-900 pt-1 mt-1">
        <span className="text-green-500 shrink-0">user@raos:~$</span>
        <input
          ref={inputRef}
          className="flex-1 bg-transparent outline-none text-green-200 caret-green-400"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
          spellCheck={false}
          autoComplete="off"
        />
      </div>
    </div>
  );
}
