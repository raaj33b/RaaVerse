import { useState } from 'react';
import { useOS } from '../hooks/useOS';
import { store } from '../store/osStore';

type FSNode = {
  name: string;
  type: 'dir' | 'file';
  path: string;
  size?: number;
  modified?: string;
  children?: FSNode[];
};

export default function Filesystem() {
  const state = useOS();
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['/sandbox/', '/sandbox/fs/']));
  const [selected, setSelected] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const tree: FSNode = {
    name: 'sandbox', type: 'dir', path: '/sandbox/',
    children: [
      {
        name: 'kernel', type: 'dir', path: '/sandbox/kernel/',
        children: [
          { name: 'init', type: 'file', path: '/sandbox/kernel/init', size: 4096 },
          { name: 'proc-mgr', type: 'file', path: '/sandbox/kernel/proc-mgr', size: 8192 },
          { name: 'cow-layer', type: 'file', path: '/sandbox/kernel/cow-layer', size: 2048 },
        ],
      },
      {
        name: 'fs', type: 'dir', path: '/sandbox/fs/',
        children: [
          {
            name: 'notes', type: 'dir', path: '/sandbox/fs/notes/',
            children: state.notes.map(n => ({
              name: n.filename, type: 'file' as const,
              path: `/sandbox/fs/notes/${n.filename}`,
              size: n.content.length,
              modified: n.modified.split('T')[0],
            })),
          },
          {
            name: 'mail', type: 'dir', path: '/sandbox/fs/mail/',
            children: [
              {
                name: 'inbox', type: 'dir', path: '/sandbox/fs/mail/inbox/',
                children: [
                  {
                    name: 'new', type: 'dir', path: '/sandbox/fs/mail/inbox/new/',
                    children: state.emails.filter(e => e.folder === 'inbox/new').map(e => ({
                      name: e.id, type: 'file' as const,
                      path: `/sandbox/fs/mail/inbox/new/${e.id}`,
                      size: e.body.length,
                      modified: e.date,
                    })),
                  },
                  {
                    name: 'cur', type: 'dir', path: '/sandbox/fs/mail/inbox/cur/',
                    children: state.emails.filter(e => e.folder === 'inbox/cur').map(e => ({
                      name: e.id, type: 'file' as const,
                      path: `/sandbox/fs/mail/inbox/cur/${e.id}`,
                      size: e.body.length,
                      modified: e.date,
                    })),
                  },
                  { name: 'tmp', type: 'dir' as const, path: '/sandbox/fs/mail/inbox/tmp/', children: [] },
                ],
              },
              {
                name: 'sent', type: 'dir', path: '/sandbox/fs/mail/sent/',
                children: state.emails.filter(e => e.folder === 'sent').map(e => ({
                  name: e.id, type: 'file' as const, path: `/sandbox/fs/mail/sent/${e.id}`,
                  size: e.body.length, modified: e.date,
                })),
              },
              { name: 'drafts', type: 'dir' as const, path: '/sandbox/fs/mail/drafts/', children: [] },
            ],
          },
          {
            name: 'irc', type: 'dir', path: '/sandbox/fs/irc/',
            children: [
              { name: 'mirc.ini', type: 'file' as const, path: '/sandbox/fs/irc/mirc.ini', size: 128 },
              { name: 'aliases.ini', type: 'file' as const, path: '/sandbox/fs/irc/aliases.ini', size: 64 },
              { name: 'users.ini', type: 'file' as const, path: '/sandbox/fs/irc/users.ini', size: 32 },
              {
                name: 'channels', type: 'dir', path: '/sandbox/fs/irc/channels/',
                children: Object.keys(state.ircMessages).map(ch => ({
                  name: ch.slice(1) + '.log', type: 'file' as const,
                  path: `/sandbox/fs/irc/channels/${ch.slice(1)}.log`,
                  size: state.ircMessages[ch].length * 80,
                })),
              },
            ],
          },
        ],
      },
      {
        name: 'bin', type: 'dir', path: '/sandbox/bin/',
        children: ['sh', 'mail-daemon', 'irc-daemon', 'ls', 'cat', 'ps', 'ifconfig'].map(b => ({
          name: b, type: 'file' as const, path: `/sandbox/bin/${b}`, size: 4096,
        })),
      },
      {
        name: 'state', type: 'dir', path: '/sandbox/state/',
        children: [
          { name: 'session.snap', type: 'file' as const, path: '/sandbox/state/session.snap', size: 16384 },
          { name: 'cow.journal', type: 'file' as const, path: '/sandbox/state/cow.journal', size: 8192 },
        ],
      },
    ],
  };

  function toggle(path: string) {
    setExpanded(s => {
      const n = new Set(s);
      if (n.has(path)) n.delete(path); else n.add(path);
      return n;
    });
  }

  function selectNode(node: FSNode) {
    setSelected(node.path);
    store.setState(() => ({ currentPath: node.path }));
    if (node.type === 'file') {
      // Generate preview
      const notePath = '/sandbox/fs/notes/';
      if (node.path.startsWith(notePath)) {
        const fname = node.path.slice(notePath.length);
        const note = state.notes.find(n => n.filename === fname);
        setPreview(note ? note.content : '[empty]');
      } else if (node.path.includes('/mail/') && node.path.split('/').length > 5) {
        const emailId = node.path.split('/').pop() ?? '';
        const email = state.emails.find(e => e.id === emailId);
        setPreview(email ? email.body : '[no content]');
      } else if (node.path.includes('mirc.ini')) {
        const c = state.ircConfig;
        setPreview(`[mirc]\nnick=${c.nick}\nserver=${c.server}\nautojoin=${c.autojoin.join(',')}\n\n[options]\nlogging=${c.logging ? 1 : 0}\ntimestamps=${c.timestamps ? 1 : 0}`);
      } else if (node.path.endsWith('.log')) {
        const chName = '#' + node.path.split('/').pop()?.replace('.log', '');
        const msgs = state.ircMessages[chName] ?? [];
        setPreview(msgs.map(m => `[${m.timestamp.split('T')[1]?.slice(0,5)}] <${m.nick}> ${m.text}`).join('\n'));
      } else {
        setPreview(`[binary/system file]\n${node.path}\nSize: ${node.size ?? 0} bytes`);
      }
    } else {
      setPreview(null);
    }
  }

  function renderNode(node: FSNode, depth = 0) {
    const isExpanded = expanded.has(node.path);
    const isSelected = selected === node.path;
    const indent = depth * 14;

    return (
      <div key={node.path}>
        <div
          style={{ paddingLeft: indent + 6 }}
          onClick={() => { node.type === 'dir' ? toggle(node.path) : null; selectNode(node); }}
          className={`flex items-center gap-1.5 py-0.5 cursor-pointer hover:bg-green-950 transition-colors text-[10px] leading-5 ${isSelected ? 'bg-green-950 text-green-200' : 'text-green-500'}`}
        >
          {node.type === 'dir' ? (
            <span className="text-green-700 w-3 text-center">{isExpanded ? '▾' : '▸'}</span>
          ) : (
            <span className="text-green-800 w-3 text-center">·</span>
          )}
          <span>{node.type === 'dir' ? '📁' : '📄'}</span>
          <span className={node.type === 'dir' ? 'text-green-400' : 'text-green-500'}>{node.name}</span>
          {node.size !== undefined && (
            <span className="ml-auto pr-2 text-green-800">{node.size}b</span>
          )}
        </div>
        {node.type === 'dir' && isExpanded && node.children?.map(c => renderNode(c, depth + 1))}
      </div>
    );
  }

  return (
    <div className="h-full flex font-mono text-xs bg-black text-green-300">
      {/* Tree */}
      <div className="w-56 border-r border-green-900 overflow-y-auto shrink-0">
        <div className="px-2 py-1.5 border-b border-green-900 text-[10px] text-green-600">/sandbox/</div>
        {renderNode(tree)}
      </div>

      {/* Preview / Info pane */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-3 py-1 border-b border-green-900 text-[10px] text-green-600 shrink-0">
          {selected ?? state.currentPath}
        </div>
        {preview !== null ? (
          <pre className="flex-1 overflow-auto p-3 text-green-300 leading-5 whitespace-pre-wrap text-[10px]">{preview}</pre>
        ) : (
          <div className="flex-1 overflow-y-auto p-3">
            <div className="text-green-700 mb-2">CoW Filesystem — /sandbox/</div>
            <div className="grid grid-cols-2 gap-2">
              {[
                ['Type', 'Virtual (FAT-like)'],
                ['Mount', '/sandbox/'],
                ['Network', 'Isolated'],
                ['CoW', 'Active'],
                ['Notes', state.notes.length + ' files'],
                ['Emails', state.emails.length + ' messages'],
                ['IRC channels', Object.keys(state.ircMessages).length + ' channels'],
                ['Path', state.currentPath],
              ].map(([k, v]) => (
                <div key={k} className="bg-green-950/40 rounded p-2 border border-green-900">
                  <div className="text-green-700 text-[9px]">{k}</div>
                  <div className="text-green-300">{v}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
