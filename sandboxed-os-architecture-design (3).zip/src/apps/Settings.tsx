import { useState } from 'react';
import { useOS } from '../hooks/useOS';
import { store } from '../store/osStore';

export default function Settings() {
  const state = useOS();
  const cfg = state.ircConfig;
  const [nick, setNick] = useState(cfg.nick);
  const [server, setServer] = useState(cfg.server);
  const [autojoin, setAutojoin] = useState(cfg.autojoin.join(','));
  const [logging, setLogging] = useState(cfg.logging);
  const [timestamps, setTimestamps] = useState(cfg.timestamps);
  const [saved, setSaved] = useState(false);

  function handleSave() {
    store.updateIRCConfig({
      nick: nick.trim() || 'user1',
      server: server.trim() || 'irc.local:6667',
      autojoin: autojoin.split(',').map(c => c.trim()).filter(Boolean),
      logging,
      timestamps,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function resetState() {
    if (confirm('Reset all RaaOs state? This cannot be undone.')) {
      localStorage.removeItem('raoos_state');
      window.location.reload();
    }
  }

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="flex flex-col gap-1">
      <label className="text-green-600 text-[10px] uppercase tracking-wider">{label}</label>
      {children}
    </div>
  );

  const inputCls = "bg-black border border-green-800 rounded px-2 py-1.5 text-green-200 text-xs outline-none focus:border-green-500 font-mono";

  return (
    <div className="h-full overflow-auto p-4 font-mono text-xs bg-black text-green-300">
      <div className="max-w-lg mx-auto space-y-6">
        {/* mirc.ini */}
        <section>
          <div className="text-green-500 text-[10px] uppercase tracking-widest mb-3 flex items-center gap-2">
            <span>mirc.ini</span>
            <span className="text-green-800">— /sandbox/fs/irc/mirc.ini</span>
          </div>
          <div className="bg-green-950/20 border border-green-900 rounded-lg p-4 space-y-4">
            <div className="text-green-700 text-[10px]">[mirc]</div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="nick">
                <input className={inputCls} value={nick} onChange={e => setNick(e.target.value)} />
              </Field>
              <Field label="server">
                <input className={inputCls} value={server} onChange={e => setServer(e.target.value)} />
              </Field>
            </div>
            <Field label="autojoin (comma-separated)">
              <input className={inputCls} value={autojoin} onChange={e => setAutojoin(e.target.value)} placeholder="#general,#ideas" />
            </Field>
            <div className="text-green-700 text-[10px] mt-2">[options]</div>
            <div className="flex gap-6">
              {[['logging', logging, setLogging], ['timestamps', timestamps, setTimestamps]].map(([label, val, setter]) => (
                <label key={label as string} className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => (setter as (v: boolean) => void)(!(val as boolean))}
                    className={`w-8 h-4 rounded-full transition-colors relative ${val ? 'bg-green-600' : 'bg-green-900'}`}
                  >
                    <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform ${val ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </div>
                  <span className="text-green-500">{label as string}={val ? '1' : '0'}</span>
                </label>
              ))}
            </div>
          </div>
        </section>

        {/* System info */}
        <section>
          <div className="text-green-500 text-[10px] uppercase tracking-widest mb-3">System</div>
          <div className="bg-green-950/20 border border-green-900 rounded-lg p-4 space-y-2">
            {[
              ['OS', 'RaaOs v1.0'],
              ['Kernel', 'raos-kernel #1 SMP'],
              ['Network', 'Loopback-only (sandboxed)'],
              ['CoW layer', 'Active'],
              ['Privacy', 'Maximum'],
              ['Author', 'raajeeb@addy.io'],
              ['Rights', 'All rights reserved'],
            ].map(([k, v]) => (
              <div key={k} className="flex gap-3">
                <span className="text-green-700 w-24 shrink-0">{k}:</span>
                <span className="text-green-300">{v}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Sandbox stats */}
        <section>
          <div className="text-green-500 text-[10px] uppercase tracking-widest mb-3">Sandbox Status</div>
          <div className="bg-green-950/20 border border-green-900 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-green-600">CPU Load</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-green-950 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full transition-all" style={{ width: `${state.cpuLoad}%` }} />
                </div>
                <span className="text-green-400 w-8 text-right">{Math.round(state.cpuLoad)}%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-green-600">Memory</span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-green-950 rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500 rounded-full transition-all" style={{ width: `${state.memUsed}%` }} />
                </div>
                <span className="text-green-400 w-8 text-right">{Math.round(state.memUsed)}%</span>
              </div>
            </div>
          </div>
        </section>

        {/* Actions */}
        <div className="flex gap-3 flex-wrap">
          <button
            onClick={handleSave}
            className={`px-4 py-2 rounded border text-xs transition-all ${saved ? 'bg-green-700 border-green-500 text-green-100' : 'bg-green-900 border-green-700 text-green-200 hover:bg-green-800'}`}
          >
            {saved ? '✓ Saved to mirc.ini' : 'Save Settings'}
          </button>
          <button
            onClick={resetState}
            className="px-4 py-2 rounded border border-red-900 text-red-500 hover:bg-red-950 text-xs transition-all"
          >
            Reset OS State
          </button>
        </div>
      </div>
    </div>
  );
}
