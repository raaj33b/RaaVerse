import { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { useOS } from '../hooks/useOS';
import { store } from '../store/osStore';

export default function IRC() {
  const state = useOS();
  const [input, setInput] = useState('');
  const [joinInput, setJoinInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const channel = state.activeChannel;
  const messages = state.ircMessages[channel] ?? [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [messages.length, channel]);

  useEffect(() => { inputRef.current?.focus(); }, [channel]);

  function handleSend() {
    const text = input.trim();
    if (!text) return;

    if (text.startsWith('/join ')) {
      store.joinChannel(text.slice(6).trim());
    } else if (text.startsWith('/nick ')) {
      store.updateIRCConfig({ nick: text.slice(6).trim() });
    } else if (text.startsWith('/part')) {
      const chs = state.ircConfig.autojoin.filter(c => c !== channel);
      store.updateIRCConfig({ autojoin: chs });
      store.setActiveChannel(chs[0] ?? '#general');
    } else if (text === '/quit') {
      store.updateIRCConfig({ autojoin: ['#general'] });
      store.setActiveChannel('#general');
    } else {
      store.sendIRCMessage(channel, text);
    }
    setInput('');
  }

  function handleKey(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') handleSend();
  }

  function handleJoin(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter' && joinInput.trim()) {
      store.joinChannel(joinInput.trim());
      setJoinInput('');
    }
  }

  const channels = state.ircConfig.autojoin;

  return (
    <div className="h-full flex font-mono text-xs bg-black text-green-300">
      {/* Channel list */}
      <div className="w-36 border-r border-green-900 flex flex-col shrink-0">
        <div className="px-3 py-1.5 text-green-500 text-[10px] uppercase tracking-widest border-b border-green-900">
          {state.ircConfig.server}
        </div>
        {channels.map(ch => (
          <button
            key={ch}
            onClick={() => store.setActiveChannel(ch)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-left hover:bg-green-950 transition-colors truncate ${channel === ch ? 'bg-green-950 text-green-200' : 'text-green-600'}`}
          >
            <span className="text-green-700">#</span>
            <span className="truncate">{ch.slice(1)}</span>
          </button>
        ))}
        <div className="flex items-center gap-1 px-2 py-1 mt-auto border-t border-green-900">
          <span className="text-green-700">/join</span>
          <input
            className="flex-1 bg-transparent outline-none text-green-300 w-0"
            placeholder="#ch"
            value={joinInput}
            onChange={e => setJoinInput(e.target.value)}
            onKeyDown={handleJoin}
          />
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Channel header */}
        <div className="flex items-center gap-2 px-3 py-1 border-b border-green-900 shrink-0 bg-green-950/30">
          <span className="text-green-400 font-bold">{channel}</span>
          <span className="text-green-700 text-[10px]">/sandbox/fs/irc/channels/{channel.slice(1)}.log</span>
          <span className="ml-auto text-green-700 text-[10px]">nick: <span className="text-green-400">{state.ircConfig.nick}</span></span>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
          {messages.map(msg => (
            <div key={msg.id} className="flex items-start gap-2 leading-5">
              {state.ircConfig.timestamps && (
                <span className="text-green-800 shrink-0 text-[9px] mt-0.5">
                  {msg.timestamp.split('T')[1]?.slice(0, 5)}
                </span>
              )}
              {msg.type === 'system' || msg.type === 'join' || msg.type === 'part' ? (
                <span className="text-green-700 italic">* {msg.text}</span>
              ) : (
                <>
                  <span className={`shrink-0 font-bold ${msg.nick === state.ircConfig.nick ? 'text-cyan-400' : msg.nick === 'raaos-bot' ? 'text-yellow-400' : 'text-green-400'}`}>
                    &lt;{msg.nick}&gt;
                  </span>
                  <span className="text-green-200 break-all">{msg.text}</span>
                </>
              )}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="flex items-center gap-2 border-t border-green-900 px-2 py-1.5 shrink-0">
          <span className="text-green-600 shrink-0">[{state.ircConfig.nick}]</span>
          <input
            ref={inputRef}
            className="flex-1 bg-transparent outline-none text-green-200 caret-green-400"
            placeholder="Message or /command"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            spellCheck={false}
          />
          <button
            onClick={handleSend}
            className="px-2 py-0.5 bg-green-900 hover:bg-green-800 text-green-200 rounded border border-green-700"
          >
            Send
          </button>
        </div>
      </div>

      {/* User list / info */}
      <div className="w-32 border-l border-green-900 flex flex-col shrink-0">
        <div className="px-2 py-1.5 border-b border-green-900 text-[10px] text-green-600">Users</div>
        {['kernel', state.ircConfig.nick, 'raaos-bot'].map(u => (
          <div key={u} className="flex items-center gap-1.5 px-2 py-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 shrink-0" />
            <span className={`truncate text-[10px] ${u === state.ircConfig.nick ? 'text-cyan-400' : u === 'raaos-bot' ? 'text-yellow-400' : 'text-green-500'}`}>{u}</span>
          </div>
        ))}
        <div className="flex-1" />
        <div className="px-2 py-2 text-[9px] text-green-800 border-t border-green-900">
          <div>irc.local:6667</div>
          <div className="text-green-900">loopback-only</div>
        </div>
      </div>
    </div>
  );
}
