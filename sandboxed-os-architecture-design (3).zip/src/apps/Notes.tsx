import { useState } from 'react';
import { useOS } from '../hooks/useOS';
import { store, Note } from '../store/osStore';

export default function Notes() {
  const state = useOS();
  const [selected, setSelected] = useState<string | null>(state.notes[0]?.id ?? null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameVal, setRenameVal] = useState('');
  const [draft, setDraft] = useState<Record<string, string>>({});

  const note = state.notes.find(n => n.id === selected);
  const content = selected ? (draft[selected] ?? note?.content ?? '') : '';

  function selectNote(id: string) {
    setSelected(id);
    setRenaming(null);
  }

  function handleEdit(val: string) {
    if (!selected) return;
    setDraft(d => ({ ...d, [selected]: val }));
  }

  function handleSave() {
    if (!selected) return;
    store.saveNote(selected, content);
    setDraft(d => { const n = { ...d }; delete n[selected]; return n; });
  }

  function handleNew() {
    const id = store.newNote();
    setSelected(id);
    setDraft(d => ({ ...d, [id]: '' }));
  }

  function handleDelete(id: string) {
    store.deleteNote(id);
    const remaining = state.notes.filter(n => n.id !== id);
    setSelected(remaining[0]?.id ?? null);
    setDraft(d => { const n = { ...d }; delete n[id]; return n; });
  }

  function startRename(n: Note) {
    setRenaming(n.id);
    setRenameVal(n.filename);
  }

  function commitRename(id: string) {
    if (renameVal.trim()) store.renameNote(id, renameVal.trim());
    setRenaming(null);
  }

  const isDirty = selected && draft[selected] !== undefined;

  return (
    <div className="h-full flex font-mono text-xs bg-black text-green-300">
      {/* File list */}
      <div className="w-44 border-r border-green-900 flex flex-col shrink-0">
        <div className="px-2 py-1.5 text-[10px] text-green-600 border-b border-green-900 flex items-center justify-between">
          <span>/sandbox/fs/notes/</span>
          <button onClick={handleNew} className="text-green-400 hover:text-green-200 text-base leading-none" title="New note">+</button>
        </div>
        <div className="flex-1 overflow-y-auto">
          {state.notes.map(n => (
            <div
              key={n.id}
              onClick={() => selectNote(n.id)}
              className={`group flex items-center px-2 py-1.5 cursor-pointer border-b border-green-950 hover:bg-green-950 transition-colors ${selected === n.id ? 'bg-green-950' : ''}`}
            >
              <span className="text-green-700 shrink-0 mr-1">📄</span>
              {renaming === n.id ? (
                <input
                  autoFocus
                  className="flex-1 bg-transparent outline-none border-b border-green-500 text-green-200 min-w-0"
                  value={renameVal}
                  onChange={e => setRenameVal(e.target.value)}
                  onBlur={() => commitRename(n.id)}
                  onKeyDown={e => e.key === 'Enter' && commitRename(n.id)}
                />
              ) : (
                <span
                  className="flex-1 truncate text-green-400"
                  onDoubleClick={() => startRename(n)}
                >
                  {n.filename}
                  {draft[n.id] !== undefined && <span className="text-yellow-500">*</span>}
                </span>
              )}
              <button
                onClick={e => { e.stopPropagation(); handleDelete(n.id); }}
                className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-400 ml-1 shrink-0"
              >×</button>
            </div>
          ))}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {note ? (
          <>
            <div className="flex items-center justify-between px-3 py-1 border-b border-green-900 shrink-0 bg-green-950/20">
              <span className="text-green-600 text-[10px]">/sandbox/fs/notes/{note.filename}</span>
              <div className="flex items-center gap-2 text-[10px]">
                <span className="text-green-800">mod: {note.modified.split('T')[0]}</span>
                {isDirty && (
                  <button
                    onClick={handleSave}
                    className="px-2 py-0.5 bg-green-800 hover:bg-green-700 text-green-100 rounded border border-green-600"
                  >
                    Save
                  </button>
                )}
              </div>
            </div>
            <textarea
              className="flex-1 bg-transparent text-green-200 outline-none resize-none p-3 leading-5 caret-green-400"
              value={content}
              onChange={e => handleEdit(e.target.value)}
              onKeyDown={e => {
                if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                  e.preventDefault();
                  handleSave();
                }
              }}
              spellCheck={false}
              placeholder="Start typing..."
            />
            <div className="px-3 py-0.5 border-t border-green-900 text-[9px] text-green-800 flex gap-4">
              <span>{content.length} chars</span>
              <span>{content.split('\n').length} lines</span>
              <span className="ml-auto">Ctrl+S to save</span>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-green-800">
            <div className="text-4xl mb-2">📝</div>
            <div>No note selected</div>
            <button onClick={handleNew} className="mt-3 px-4 py-1.5 bg-green-950 hover:bg-green-900 text-green-400 rounded border border-green-800 text-xs">
              + New note
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
