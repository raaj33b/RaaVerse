import { useState } from 'react';
import { useOS } from '../hooks/useOS';
import { store, Email } from '../store/osStore';

type Folder = 'inbox/new' | 'inbox/cur' | 'sent' | 'drafts';

export default function Mail() {
  const state = useOS();
  const [folder, setFolder] = useState<Folder>('inbox/new');
  const [selected, setSelected] = useState<Email | null>(null);
  const [composing, setComposing] = useState(false);
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');

  const folders: { key: Folder; label: string; icon: string }[] = [
    { key: 'inbox/new', label: 'Inbox/New', icon: '📬' },
    { key: 'inbox/cur', label: 'Inbox/Cur', icon: '📭' },
    { key: 'sent', label: 'Sent', icon: '📤' },
    { key: 'drafts', label: 'Drafts', icon: '📝' },
  ];

  const emails = state.emails.filter(e => e.folder === folder);
  const unreadNew = state.emails.filter(e => e.folder === 'inbox/new').length;

  function selectEmail(e: Email) {
    setSelected(e);
    setComposing(false);
    store.markRead(e.id);
  }

  function handleSend() {
    if (!to || !subject) return;
    store.sendEmail(to, subject, body);
    setComposing(false);
    setTo(''); setSubject(''); setBody('');
  }

  return (
    <div className="h-full flex font-mono text-xs bg-black text-green-300">
      {/* Sidebar */}
      <div className="w-36 border-r border-green-900 flex flex-col py-2 shrink-0">
        <div className="px-3 py-1 text-green-500 text-[10px] uppercase tracking-widest">Maildir</div>
        {folders.map(f => (
          <button
            key={f.key}
            onClick={() => { setFolder(f.key); setSelected(null); setComposing(false); }}
            className={`flex items-center gap-2 px-3 py-1.5 text-left hover:bg-green-950 transition-colors ${folder === f.key ? 'bg-green-950 text-green-300' : 'text-green-600'}`}
          >
            <span>{f.icon}</span>
            <span className="truncate">{f.label}</span>
            {f.key === 'inbox/new' && unreadNew > 0 && (
              <span className="ml-auto bg-green-500 text-black px-1 rounded text-[9px]">{unreadNew}</span>
            )}
          </button>
        ))}
        <div className="flex-1" />
        <button
          onClick={() => { setComposing(true); setSelected(null); }}
          className="mx-2 mb-2 px-2 py-1.5 bg-green-900 hover:bg-green-800 text-green-200 rounded text-[10px] border border-green-700"
        >
          ✉ Compose
        </button>
      </div>

      {/* Email list */}
      <div className="w-48 border-r border-green-900 overflow-y-auto shrink-0">
        <div className="px-2 py-1.5 border-b border-green-900 text-[10px] text-green-600">
          /sandbox/fs/mail/{folder}/
        </div>
        {emails.length === 0 && (
          <div className="px-3 py-4 text-green-800 text-center">Empty</div>
        )}
        {emails.map(e => (
          <div
            key={e.id}
            onClick={() => selectEmail(e)}
            className={`px-2 py-2 border-b border-green-950 cursor-pointer hover:bg-green-950 transition-colors ${selected?.id === e.id ? 'bg-green-950' : ''}`}
          >
            <div className={`truncate ${!e.read ? 'text-green-200 font-bold' : 'text-green-500'}`}>{e.subject}</div>
            <div className="text-green-700 truncate text-[9px]">{e.from}</div>
            <div className="text-green-800 text-[9px]">{e.date}</div>
          </div>
        ))}
      </div>

      {/* Content pane */}
      <div className="flex-1 overflow-auto p-3">
        {composing ? (
          <div className="flex flex-col gap-2 h-full">
            <div className="text-green-500 text-[10px] uppercase tracking-widest mb-1">Compose — /sandbox/fs/mail/drafts/</div>
            {[['To', to, setTo], ['Subject', subject, setSubject]].map(([label, val, setter]) => (
              <div key={label as string} className="flex items-center gap-2 border-b border-green-900 pb-1">
                <span className="text-green-600 w-14 shrink-0">{label as string}:</span>
                <input
                  className="flex-1 bg-transparent outline-none text-green-200"
                  value={val as string}
                  onChange={e => (setter as (v: string) => void)(e.target.value)}
                  placeholder={label === 'To' ? 'user@raos.local' : ''}
                />
              </div>
            ))}
            <textarea
              className="flex-1 bg-transparent outline-none text-green-200 resize-none border border-green-900 rounded p-2 mt-1"
              placeholder="Body..."
              value={body}
              onChange={e => setBody(e.target.value)}
            />
            <div className="flex gap-2">
              <button onClick={handleSend} className="px-4 py-1.5 bg-green-800 hover:bg-green-700 text-green-100 rounded border border-green-600 text-xs">
                Send (loopback)
              </button>
              <button onClick={() => setComposing(false)} className="px-4 py-1.5 bg-black hover:bg-green-950 text-green-400 rounded border border-green-900 text-xs">
                Cancel
              </button>
            </div>
          </div>
        ) : selected ? (
          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center">
              <div className="text-green-500 text-[10px]">/sandbox/fs/mail/{selected.folder}/{selected.id}</div>
              <button onClick={() => { store.deleteEmail(selected.id); setSelected(null); }} className="text-red-500 hover:text-red-400 text-[10px]">
                🗑 Delete
              </button>
            </div>
            <pre className="text-green-300 leading-5 whitespace-pre-wrap">{selected.body}</pre>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-green-800">
            <div className="text-4xl mb-2">📬</div>
            <div>Select a message</div>
            <div className="text-[10px] mt-1">/sandbox/fs/mail/</div>
          </div>
        )}
      </div>
    </div>
  );
}
