import React, { useRef, useCallback, useEffect } from 'react';
import { store } from '../store/osStore';

interface Props {
  id: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  minimized: boolean;
  maximized: boolean;
  zIndex: number;
  children: React.ReactNode;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
}

export default function OSWindow({
  id, title, x, y, width, height, minimized, maximized, zIndex,
  children, onClose, onMinimize, onMaximize,
}: Props) {
  const dragRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);
  const windowRef = useRef<HTMLDivElement>(null);

  const onMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('.win-btn')) return;
    store.bringToFront(id);
    dragRef.current = { startX: e.clientX, startY: e.clientY, origX: x, origY: y };
    e.preventDefault();
  }, [id, x, y]);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!dragRef.current || maximized) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      store.moveWindow(id, dragRef.current.origX + dx, dragRef.current.origY + dy);
    };
    const onMouseUp = () => { dragRef.current = null; };
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, [id, maximized]);

  if (minimized) return null;

  const style: React.CSSProperties = maximized
    ? { position: 'fixed', top: 28, left: 0, right: 0, bottom: 28, zIndex, width: '100%', height: 'calc(100vh - 56px)' }
    : { position: 'absolute', top: y, left: x, width, height, zIndex };

  return (
    <div
      ref={windowRef}
      style={style}
      className="flex flex-col rounded-lg overflow-hidden shadow-2xl border border-green-700/60 bg-black/95 backdrop-blur-sm select-none"
      onMouseDown={() => store.bringToFront(id)}
    >
      {/* Title bar */}
      <div
        className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-green-950 to-black border-b border-green-800/60 cursor-move shrink-0"
        onMouseDown={onMouseDown}
      >
        <div className="flex gap-1.5 win-btn">
          <button
            onClick={onClose}
            className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-400 transition-colors border border-red-700"
            title="Close"
          />
          <button
            onClick={onMinimize}
            className="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-400 transition-colors border border-yellow-700"
            title="Minimize"
          />
          <button
            onClick={onMaximize}
            className="w-3 h-3 rounded-full bg-green-500 hover:bg-green-400 transition-colors border border-green-700"
            title="Maximize"
          />
        </div>
        <span className="flex-1 text-center text-xs font-mono text-green-400 truncate pointer-events-none">
          {title}
        </span>
        <div className="w-12" />
      </div>
      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {children}
      </div>
    </div>
  );
}
