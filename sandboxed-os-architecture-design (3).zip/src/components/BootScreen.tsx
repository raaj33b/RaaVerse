import { useEffect, useState } from 'react';
import { store } from '../store/osStore';

const BOOT_SEQUENCE = [
  { text: 'RaaOs v1.0 — Minimal Sandboxed OS', delay: 0, color: 'text-green-300 font-bold text-sm' },
  { text: '© raajeeb@addy.io · All rights reserved', delay: 80, color: 'text-green-600 text-xs' },
  { text: '', delay: 160, color: '' },
  { text: 'BIOS v1.0 — RaaOs ROM', delay: 240, color: 'text-gray-500 text-xs' },
  { text: 'Detecting hardware...', delay: 320, color: 'text-gray-500 text-xs' },
  { text: '', delay: 400, color: '' },
  { text: '[BOOT] Loading kernel image...', delay: 500, color: 'text-green-500' },
  { text: '[BOOT] Initializing process manager...', delay: 650, color: 'text-green-500' },
  { text: '[BOOT] Mounting virtual filesystem at /sandbox/fs/', delay: 800, color: 'text-green-500' },
  { text: '[BOOT] Mounting /sandbox/fs/notes/ ... OK', delay: 950, color: 'text-green-400' },
  { text: '[BOOT] Mounting /sandbox/fs/mail/  ... OK', delay: 1100, color: 'text-green-400' },
  { text: '[BOOT] Mounting /sandbox/fs/irc/   ... OK', delay: 1250, color: 'text-green-400' },
  { text: '[BOOT] Starting copy-on-write layer ...', delay: 1400, color: 'text-cyan-500' },
  { text: '[BOOT] CoW journal: /sandbox/state/cow.journal', delay: 1550, color: 'text-cyan-400' },
  { text: '[BOOT] Enforcing network sandbox (loopback-only)...', delay: 1700, color: 'text-yellow-500' },
  { text: '[BOOT] External interfaces: DISABLED', delay: 1850, color: 'text-red-400' },
  { text: '[BOOT] Starting mail daemon on 127.0.0.1:25 ...', delay: 2000, color: 'text-green-500' },
  { text: '[BOOT] Starting IRC daemon on irc.local:6667 ...', delay: 2150, color: 'text-green-500' },
  { text: '[BOOT] Loading session from /sandbox/state/session.snap ...', delay: 2300, color: 'text-green-500' },
  { text: '', delay: 2450, color: '' },
  { text: '[ OK ] All systems nominal.', delay: 2600, color: 'text-green-300 font-bold' },
  { text: '[ OK ] Security: MAXIMUM', delay: 2700, color: 'text-green-300' },
  { text: '[ OK ] Privacy: MAXIMUM', delay: 2800, color: 'text-green-300' },
  { text: '[ OK ] Network isolation: ACTIVE', delay: 2900, color: 'text-green-300' },
  { text: '', delay: 3000, color: '' },
  { text: 'Welcome to RaaOs. Starting desktop...', delay: 3100, color: 'text-green-400 font-bold' },
];

export default function BootScreen({ onDone }: { onDone: () => void }) {
  const [visibleCount, setVisibleCount] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    BOOT_SEQUENCE.forEach((_, i) => {
      timers.push(setTimeout(() => setVisibleCount(i + 1), BOOT_SEQUENCE[i].delay));
    });
    timers.push(setTimeout(() => {
      setDone(true);
      setTimeout(() => {
        store.setBootComplete();
        onDone();
      }, 500);
    }, 3400));
    return () => timers.forEach(clearTimeout);
  }, [onDone]);

  return (
    <div className={`fixed inset-0 bg-black flex flex-col items-center justify-center transition-opacity duration-500 ${done ? 'opacity-0' : 'opacity-100'}`}>
      <div className="w-full max-w-2xl px-8">
        {/* Logo */}
        <div className="text-center mb-6">
          <pre className="text-green-500 text-xs leading-tight select-none">
{`  ██████╗  █████╗  █████╗  ██████╗ ███████╗
  ██╔══██╗██╔══██╗██╔══██╗██╔═══██╗██╔════╝
  ██████╔╝███████║███████║██║   ██║███████╗
  ██╔══██╗██╔══██║██╔══██║██║   ██║╚════██║
  ██║  ██║██║  ██║██║  ██║╚██████╔╝███████║
  ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝`}
          </pre>
        </div>
        {/* Boot log */}
        <div className="font-mono text-xs space-y-0.5 min-h-48">
          {BOOT_SEQUENCE.slice(0, visibleCount).map((line, i) => (
            <div key={i} className={`leading-5 ${line.color}`}>
              {line.text || '\u00A0'}
            </div>
          ))}
          {visibleCount < BOOT_SEQUENCE.length && (
            <span className="inline-block w-2 h-3.5 bg-green-400 animate-pulse ml-1" />
          )}
        </div>
        {/* Bottom bar */}
        <div className="mt-8 border-t border-green-900 pt-3 flex justify-between text-[10px] text-green-800 font-mono">
          <span>raos-kernel v1.0</span>
          <span>raajeeb@addy.io</span>
          <span>loopback-only · CoW active</span>
        </div>
      </div>
    </div>
  );
}
