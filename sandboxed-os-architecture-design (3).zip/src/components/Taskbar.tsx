import { useOS } from '../hooks/useOS';
import { store, AppId } from '../store/osStore';

const APPS: { id: AppId; label: string; icon: string }[] = [
  { id: 'terminal', label: 'Terminal', icon: '⌨️' },
  { id: 'mail', label: 'Mail', icon: '📬' },
  { id: 'irc', label: 'mIRC', icon: '💬' },
  { id: 'notes', label: 'Notes', icon: '📝' },
  { id: 'fs', label: 'Files', icon: '🗂️' },
  { id: 'settings', label: 'Settings', icon: '⚙️' },
];

export default function Taskbar() {
  const state = useOS();
  const time = new Date(state.systemTime);
  const timeStr = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const dateStr = time.toLocaleDateString([], { month: 'short', day: '2-digit' });

  const unreadMail = state.emails.filter(e => !e.read && e.folder === 'inbox/new').length;

  return (
    <div className="fixed bottom-0 left-0 right-0 h-8 bg-black/95 border-t border-green-900 flex items-center px-2 gap-1 z-[9999] font-mono text-xs select-none backdrop-blur-sm">
      {/* Start / Logo */}
      <button
        onClick={() => store.openApp('terminal')}
        className="flex items-center gap-1.5 px-2 py-0.5 bg-green-900 hover:bg-green-800 text-green-200 rounded border border-green-700 shrink-0 transition-colors"
      >
        <span className="text-green-400 font-bold">RaaOs</span>
      </button>

      <div className="w-px h-4 bg-green-900 mx-1" />

      {/* App launchers */}
      {APPS.map(app => {
        const win = state.windows.find(w => w.app === app.id);
        const active = win && !win.minimized;
        return (
          <button
            key={app.id}
            onClick={() => win ? (win.minimized ? store.openApp(app.id) : store.minimizeWindow(win.id)) : store.openApp(app.id)}
            className={`relative flex items-center gap-1 px-2 py-0.5 rounded text-[10px] transition-colors border ${
              active
                ? 'bg-green-800 border-green-600 text-green-100'
                : win
                ? 'bg-green-950 border-green-800 text-green-400'
                : 'bg-transparent border-transparent text-green-700 hover:text-green-400 hover:bg-green-950'
            }`}
            title={app.label}
          >
            <span>{app.icon}</span>
            <span className="hidden sm:inline">{app.label}</span>
            {app.id === 'mail' && unreadMail > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] rounded-full w-3.5 h-3.5 flex items-center justify-center">
                {unreadMail}
              </span>
            )}
            {win && (
              <span className={`w-1 h-1 rounded-full ${active ? 'bg-green-400' : 'bg-green-700'}`} />
            )}
          </button>
        );
      })}

      <div className="flex-1" />

      {/* Status indicators */}
      <div className="flex items-center gap-2 text-[9px] text-green-700">
        <span className="text-green-800">CPU</span>
        <div className="w-12 h-1.5 bg-green-950 rounded-full overflow-hidden">
          <div className="h-full bg-green-600 rounded-full transition-all duration-1000" style={{ width: `${state.cpuLoad}%` }} />
        </div>
        <span className="text-green-800">MEM</span>
        <div className="w-12 h-1.5 bg-green-950 rounded-full overflow-hidden">
          <div className="h-full bg-cyan-600 rounded-full transition-all duration-1000" style={{ width: `${state.memUsed}%` }} />
        </div>
        <div className="w-px h-3 bg-green-900" />
        <span className="text-green-600">🔒 sandbox</span>
        <div className="w-px h-3 bg-green-900" />
        <span className="text-green-500">{dateStr} {timeStr}</span>
      </div>
    </div>
  );
}
