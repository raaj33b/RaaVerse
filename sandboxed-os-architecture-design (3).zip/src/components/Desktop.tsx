import React from 'react';
import { useOS } from '../hooks/useOS';
import { store, AppId } from '../store/osStore';
import OSWindow from './OSWindow';
import Terminal from '../apps/Terminal';
import Mail from '../apps/Mail';
import IRC from '../apps/IRC';
import Notes from '../apps/Notes';
import Filesystem from '../apps/Filesystem';
import Settings from '../apps/Settings';

const APP_COMPONENTS: Record<AppId, React.ComponentType> = {
  desktop: () => null,
  terminal: Terminal,
  mail: Mail,
  irc: IRC,
  notes: Notes,
  fs: Filesystem,
  settings: Settings,
};

const DESKTOP_ICONS = [
  { id: 'terminal' as AppId, label: 'Terminal', icon: '⌨️' },
  { id: 'mail' as AppId, label: 'Mail', icon: '📬' },
  { id: 'irc' as AppId, label: 'mIRC', icon: '💬' },
  { id: 'notes' as AppId, label: 'Notes', icon: '📝' },
  { id: 'fs' as AppId, label: 'Files', icon: '🗂️' },
  { id: 'settings' as AppId, label: 'Settings', icon: '⚙️' },
];

export default function Desktop() {
  const state = useOS();

  return (
    <div className="fixed inset-0 bottom-8 top-7 overflow-hidden bg-black select-none"
      style={{ background: 'radial-gradient(ellipse at center, #001a00 0%, #000800 50%, #000000 100%)' }}
    >
      {/* Scanlines overlay */}
      <div
        className="absolute inset-0 pointer-events-none z-10 opacity-[0.03]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,0,0.3) 2px, rgba(0,255,0,0.3) 4px)',
        }}
      />

      {/* Grid pattern */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage: 'linear-gradient(rgba(0,255,0,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,0,0.1) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      {/* Desktop icons */}
      <div className="absolute top-4 left-4 flex flex-col gap-3 z-20">
        {DESKTOP_ICONS.map(icon => (
          <button
            key={icon.id}
            onDoubleClick={() => store.openApp(icon.id)}
            className="flex flex-col items-center gap-1 p-2 rounded hover:bg-green-900/30 transition-colors group w-16"
            title={`Double-click to open ${icon.label}`}
          >
            <span className="text-2xl group-hover:scale-110 transition-transform">{icon.icon}</span>
            <span className="text-[9px] font-mono text-green-600 group-hover:text-green-400 text-center leading-tight">{icon.label}</span>
          </button>
        ))}
      </div>

      {/* Windows */}
      <div className="absolute inset-0">
        {state.windows.map(win => {
          const AppComp = APP_COMPONENTS[win.app];
          return (
            <OSWindow
              key={win.id}
              {...win}
              onClose={() => store.closeWindow(win.id)}
              onMinimize={() => store.minimizeWindow(win.id)}
              onMaximize={() => store.maximizeWindow(win.id)}
            >
              <AppComp />
            </OSWindow>
          );
        })}
      </div>

      {/* No windows hint */}
      {state.windows.filter(w => !w.minimized).length === 0 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-green-900 font-mono text-xs z-10 pointer-events-none">
          <div className="text-6xl mb-4 opacity-30">⌨</div>
          <div className="text-lg font-bold opacity-40">RaaOs</div>
          <div className="opacity-30 mt-1">Double-click icons or use taskbar to open apps</div>
        </div>
      )}
    </div>
  );
}
