import { useOS } from '../hooks/useOS';

export default function TopBar() {
  const state = useOS();
  const time = new Date(state.systemTime);
  const timeStr = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="fixed top-0 left-0 right-0 h-7 bg-black/95 border-b border-green-900 flex items-center px-3 z-[9999] font-mono text-[10px] select-none backdrop-blur-sm">
      <span className="text-green-500 font-bold mr-4">RaaOs</span>
      <div className="flex items-center gap-3 text-green-800">
        <span>/sandbox/fs/</span>
        <span>·</span>
        <span className="text-green-700">kernel v1.0</span>
        <span>·</span>
        <span className="text-green-700">irc.local:6667</span>
        <span>·</span>
        <span className="text-green-700">loopback-only</span>
      </div>
      <div className="flex-1" />
      <div className="flex items-center gap-3 text-green-700">
        <span className="text-green-500">🔒</span>
        <span>sandbox</span>
        <span>·</span>
        <span>CoW: active</span>
        <span>·</span>
        <span className="text-green-500">{timeStr}</span>
      </div>
    </div>
  );
}
