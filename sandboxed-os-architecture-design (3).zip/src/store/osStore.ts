// RaaOs — On-disk sandboxed OS state
// © raajeeb@addy.io · All rights reserved

export type AppId = 'desktop' | 'terminal' | 'mail' | 'irc' | 'notes' | 'fs' | 'settings';

export interface Email {
  id: string;
  from: string;
  to: string;
  date: string;
  subject: string;
  body: string;
  read: boolean;
  folder: 'inbox/new' | 'inbox/cur' | 'sent' | 'drafts' | 'inbox/tmp';
}

export interface Note {
  id: string;
  filename: string;
  content: string;
  created: string;
  modified: string;
}

export interface IRCMessage {
  id: string;
  channel: string;
  nick: string;
  text: string;
  timestamp: string;
  type: 'message' | 'join' | 'part' | 'system';
}

export interface IRCConfig {
  nick: string;
  server: string;
  autojoin: string[];
  logging: boolean;
  timestamps: boolean;
}

export interface Window {
  id: string;
  app: AppId;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  minimized: boolean;
  maximized: boolean;
  zIndex: number;
}

export interface OSState {
  // Windows
  windows: Window[];
  nextZIndex: number;
  // Mail
  emails: Email[];
  // Notes
  notes: Note[];
  // IRC
  ircMessages: Record<string, IRCMessage[]>;
  ircConfig: IRCConfig;
  ircConnected: boolean;
  activeChannel: string;
  // Terminal
  terminalHistory: string[];
  terminalOutput: string[];
  // Filesystem view
  currentPath: string;
  // System
  bootComplete: boolean;
  systemTime: string;
  cpuLoad: number;
  memUsed: number;
}

const now = () => new Date().toISOString();
const dateStr = () => new Date().toISOString().split('T')[0];

function generateId() {
  return Math.random().toString(36).slice(2, 10);
}

const SEED_EMAILS: Email[] = [
  {
    id: generateId(),
    from: 'kernel@raos.local',
    to: 'user@raos.local',
    date: dateStr(),
    subject: 'Welcome to RaaOs',
    body: `From: kernel@raos.local\nTo: user@raos.local\nDate: ${dateStr()}\nSubject: Welcome to RaaOs\n\nBoot sequence complete. Sandboxed OS initialized.\n\nAll subsystems nominal:\n  [OK] Virtual filesystem mounted at /sandbox/fs/\n  [OK] Mail daemon started (loopback only)\n  [OK] IRC daemon started (loopback only)\n  [OK] Copy-on-write layer active\n  [OK] Network isolation: ENABLED\n\n-- kernel@raos.local`,
    read: false,
    folder: 'inbox/new',
  },
  {
    id: generateId(),
    from: 'security@raos.local',
    to: 'user@raos.local',
    date: dateStr(),
    subject: 'Sandbox security report',
    body: `From: security@raos.local\nTo: user@raos.local\nDate: ${dateStr()}\nSubject: Sandbox security report\n\nSecurity Status: NOMINAL\n\n[PASS] No external network interfaces\n[PASS] Loopback-only IRC/SMTP\n[PASS] CoW layer verified\n[PASS] Process isolation active\n[PASS] All writes journaled\n\nNext audit: 24h\n\n-- security daemon`,
    read: false,
    folder: 'inbox/new',
  },
  {
    id: generateId(),
    from: 'irc-daemon@raos.local',
    to: 'user@raos.local',
    date: dateStr(),
    subject: 'IRC daemon: channels ready',
    body: `From: irc-daemon@raos.local\nTo: user@raos.local\nDate: ${dateStr()}\nSubject: IRC daemon: channels ready\n\nirc.local:6667 is up.\nChannels auto-joined:\n  #general\n  #ideas\n\nUse /join #channel to join more.\nAll traffic is loopback-only.\n\n-- irc-daemon`,
    read: true,
    folder: 'inbox/cur',
  },
];

const SEED_NOTES: Note[] = [
  {
    id: generateId(),
    filename: 'welcome.txt',
    content: 'RaaOs Welcome Note\n==================\n\nThis is your personal note space.\nFiles are stored at /sandbox/fs/notes/\n\nTips:\n- Press Ctrl+S to save\n- All notes persist on-disk\n- Use the filesystem browser to manage files',
    created: now(),
    modified: now(),
  },
  {
    id: generateId(),
    filename: 'architecture.txt',
    content: 'RaaOs Architecture\n==================\n\n/sandbox/\n├── kernel/    # Boot + process manager\n├── fs/        # Virtual filesystem\n│   ├── notes/ # Persistent notes\n│   ├── mail/  # Maildir-style email\n│   └── irc/   # mIRC state files\n├── bin/       # Core binaries\n└── state/     # Session snapshots\n\nKernel: Minimal monolithic\nShell: Busybox-style\nIPC: Unix sockets (loopback)\nEmail: SMTP/POP3 loopback\nIRC: InspIRCd-compatible loopback',
    created: now(),
    modified: now(),
  },
  {
    id: generateId(),
    filename: 'security.txt',
    content: 'Security Policy\n===============\n\n[RULE 1] No external network access\n[RULE 2] All IRC/email is loopback only\n[RULE 3] CoW layer — state always recoverable\n[RULE 4] Process sandboxing enforced\n[RULE 5] All disk writes journaled\n\nPrivacy: Maximum\nNetwork: Isolated\nWeight: Minimal\nSpeed: Maximum',
    created: now(),
    modified: now(),
  },
];

const SEED_IRC: Record<string, IRCMessage[]> = {
  '#general': [
    { id: generateId(), channel: '#general', nick: 'kernel', text: 'RaaOs IRC daemon started. irc.local:6667', timestamp: now(), type: 'system' },
    { id: generateId(), channel: '#general', nick: 'kernel', text: 'user1 has joined #general', timestamp: now(), type: 'join' },
    { id: generateId(), channel: '#general', nick: 'user1', text: 'Hello from the sandbox!', timestamp: now(), type: 'message' },
    { id: generateId(), channel: '#general', nick: 'raaos-bot', text: 'Welcome to RaaOs. All comms are loopback-only. Privacy: max.', timestamp: now(), type: 'message' },
  ],
  '#ideas': [
    { id: generateId(), channel: '#ideas', nick: 'kernel', text: 'RaaOs IRC daemon started. irc.local:6667', timestamp: now(), type: 'system' },
    { id: generateId(), channel: '#ideas', nick: 'user1', text: 'Idea: CoW snapshots every 5 minutes', timestamp: now(), type: 'message' },
    { id: generateId(), channel: '#ideas', nick: 'raaos-bot', text: 'Logged to /sandbox/fs/irc/channels/#ideas.log', timestamp: now(), type: 'message' },
  ],
};

const DEFAULT_IRC_CONFIG: IRCConfig = {
  nick: 'user1',
  server: 'irc.local:6667',
  autojoin: ['#general', '#ideas'],
  logging: true,
  timestamps: true,
};

const BOOT_LINES = [
  'RaaOs v1.0 — Sandboxed OS',
  '© raajeeb@addy.io · All rights reserved',
  '',
  '[BOOT] Initializing kernel...',
  '[BOOT] Loading virtual filesystem at /sandbox/fs/',
  '[BOOT] Mounting notes at /sandbox/fs/notes/',
  '[BOOT] Mounting mail at /sandbox/fs/mail/',
  '[BOOT] Mounting irc at /sandbox/fs/irc/',
  '[BOOT] Starting CoW layer...',
  '[BOOT] Isolating network (loopback-only)...',
  '[BOOT] Starting mail daemon (SMTP/POP3 loopback)...',
  '[BOOT] Starting IRC daemon on irc.local:6667...',
  '[BOOT] Loading session state from /sandbox/state/...',
  '[OK] All systems nominal.',
  '[OK] Boot complete. Welcome, user.',
  '',
  'Type "help" for available commands.',
];

// ─── Reactive Store ───────────────────────────────────────────────────────────

type Listener = () => void;

class OSStore {
  private listeners: Set<Listener> = new Set();
  public state: OSState;

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): OSState {
    try {
      const saved = localStorage.getItem('raoos_state');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...this.defaultState(),
          ...parsed,
        };
      }
    } catch {}
    return this.defaultState();
  }

  private defaultState(): OSState {
    return {
      windows: [],
      nextZIndex: 100,
      emails: SEED_EMAILS,
      notes: SEED_NOTES,
      ircMessages: SEED_IRC,
      ircConfig: DEFAULT_IRC_CONFIG,
      ircConnected: true,
      activeChannel: '#general',
      terminalHistory: [],
      terminalOutput: BOOT_LINES,
      currentPath: '/sandbox/fs/',
      bootComplete: false,
      systemTime: new Date().toISOString(),
      cpuLoad: Math.floor(Math.random() * 20) + 5,
      memUsed: Math.floor(Math.random() * 30) + 20,
    };
  }

  private save() {
    try {
      localStorage.setItem('raoos_state', JSON.stringify(this.state));
    } catch {}
  }

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.save();
    this.listeners.forEach(l => l());
  }

  setState(updater: (s: OSState) => Partial<OSState>) {
    const patch = updater(this.state);
    this.state = { ...this.state, ...patch };
    this.notify();
  }

  // ── Window management ──────────────────────────────────────────────────────

  openApp(app: AppId) {
    const existing = this.state.windows.find(w => w.app === app);
    if (existing) {
      this.bringToFront(existing.id);
      if (existing.minimized) {
        this.setState(s => ({
          windows: s.windows.map(w => w.id === existing.id ? { ...w, minimized: false } : w),
        }));
      }
      return;
    }
    const titles: Record<AppId, string> = {
      desktop: 'Desktop',
      terminal: 'Terminal — /bin/sh',
      mail: 'Mail — /sandbox/fs/mail/',
      irc: 'mIRC — irc.local:6667',
      notes: 'Notes — /sandbox/fs/notes/',
      fs: 'Filesystem — /sandbox/',
      settings: 'Settings — mirc.ini',
    };
    const offsets: Partial<Record<AppId, [number, number, number, number]>> = {
      terminal: [80, 80, 700, 420],
      mail: [120, 60, 760, 500],
      irc: [160, 50, 800, 520],
      notes: [100, 90, 680, 460],
      fs: [200, 100, 640, 440],
      settings: [240, 110, 560, 400],
    };
    const [x, y, w, h] = offsets[app] ?? [60, 60, 640, 420];
    const id = generateId();
    this.setState(s => ({
      windows: [...s.windows, {
        id, app, title: titles[app],
        x, y, width: w, height: h,
        minimized: false, maximized: false,
        zIndex: s.nextZIndex,
      }],
      nextZIndex: s.nextZIndex + 1,
    }));
  }

  closeWindow(id: string) {
    this.setState(s => ({ windows: s.windows.filter(w => w.id !== id) }));
  }

  minimizeWindow(id: string) {
    this.setState(s => ({
      windows: s.windows.map(w => w.id === id ? { ...w, minimized: true } : w),
    }));
  }

  maximizeWindow(id: string) {
    this.setState(s => ({
      windows: s.windows.map(w => w.id === id ? { ...w, maximized: !w.maximized } : w),
    }));
  }

  bringToFront(id: string) {
    this.setState(s => ({
      windows: s.windows.map(w => w.id === id ? { ...w, zIndex: s.nextZIndex } : w),
      nextZIndex: s.nextZIndex + 1,
    }));
  }

  moveWindow(id: string, x: number, y: number) {
    this.setState(s => ({
      windows: s.windows.map(w => w.id === id ? { ...w, x, y } : w),
    }));
  }

  // ── Mail ──────────────────────────────────────────────────────────────────

  sendEmail(to: string, subject: string, body: string) {
    const email: Email = {
      id: generateId(),
      from: 'user@raos.local',
      to,
      date: dateStr(),
      subject,
      body: `From: user@raos.local\nTo: ${to}\nDate: ${dateStr()}\nSubject: ${subject}\n\n${body}`,
      read: true,
      folder: 'sent',
    };
    // Simulate loopback: if to ends with @raos.local, deliver to inbox
    const delivered: Email[] = [email];
    if (to.endsWith('@raos.local') || to.endsWith('@local')) {
      delivered.push({
        ...email,
        id: generateId(),
        from: 'user@raos.local',
        read: false,
        folder: 'inbox/new',
      });
    }
    this.setState(s => ({ emails: [...s.emails, ...delivered] }));
  }

  markRead(id: string) {
    this.setState(s => ({
      emails: s.emails.map(e =>
        e.id === id ? { ...e, read: true, folder: e.folder === 'inbox/new' ? 'inbox/cur' : e.folder } : e
      ),
    }));
  }

  deleteEmail(id: string) {
    this.setState(s => ({ emails: s.emails.filter(e => e.id !== id) }));
  }

  // ── Notes ─────────────────────────────────────────────────────────────────

  saveNote(id: string, content: string) {
    this.setState(s => ({
      notes: s.notes.map(n => n.id === id ? { ...n, content, modified: now() } : n),
    }));
  }

  newNote() {
    const note: Note = {
      id: generateId(),
      filename: `note_${Date.now()}.txt`,
      content: '',
      created: now(),
      modified: now(),
    };
    this.setState(s => ({ notes: [...s.notes, note] }));
    return note.id;
  }

  deleteNote(id: string) {
    this.setState(s => ({ notes: s.notes.filter(n => n.id !== id) }));
  }

  renameNote(id: string, filename: string) {
    this.setState(s => ({
      notes: s.notes.map(n => n.id === id ? { ...n, filename } : n),
    }));
  }

  // ── IRC ───────────────────────────────────────────────────────────────────

  sendIRCMessage(channel: string, text: string) {
    if (!text.trim()) return;
    const nick = this.state.ircConfig.nick;
    const msg: IRCMessage = {
      id: generateId(),
      channel,
      nick,
      text,
      timestamp: now(),
      type: 'message',
    };
    this.setState(s => ({
      ircMessages: {
        ...s.ircMessages,
        [channel]: [...(s.ircMessages[channel] ?? []), msg],
      },
    }));
    // Simulate bot reply occasionally
    if (Math.random() < 0.35) {
      setTimeout(() => {
        const replies = [
          'Acknowledged. All traffic stays loopback.',
          'Logged to /sandbox/fs/irc/channels/' + channel + '.log',
          'CoW snapshot saved to /sandbox/state/',
          'Network isolation: ACTIVE',
          'Roger that, ' + nick + '.',
          '[raaos-bot] Privacy enforced.',
        ];
        const reply: IRCMessage = {
          id: generateId(),
          channel,
          nick: 'raaos-bot',
          text: replies[Math.floor(Math.random() * replies.length)],
          timestamp: new Date().toISOString(),
          type: 'message',
        };
        this.setState(s => ({
          ircMessages: {
            ...s.ircMessages,
            [channel]: [...(s.ircMessages[channel] ?? []), reply],
          },
        }));
      }, 1000 + Math.random() * 2000);
    }
  }

  joinChannel(channel: string) {
    if (!channel.startsWith('#')) channel = '#' + channel;
    const cfg = this.state.ircConfig;
    const sys: IRCMessage = {
      id: generateId(), channel, nick: 'kernel',
      text: `${cfg.nick} has joined ${channel}`,
      timestamp: now(), type: 'join',
    };
    this.setState(s => ({
      ircMessages: { ...s.ircMessages, [channel]: [...(s.ircMessages[channel] ?? []), sys] },
      ircConfig: { ...s.ircConfig, autojoin: s.ircConfig.autojoin.includes(channel) ? s.ircConfig.autojoin : [...s.ircConfig.autojoin, channel] },
      activeChannel: channel,
    }));
  }

  setActiveChannel(ch: string) {
    this.setState(() => ({ activeChannel: ch }));
  }

  updateIRCConfig(cfg: Partial<IRCConfig>) {
    this.setState(s => ({ ircConfig: { ...s.ircConfig, ...cfg } }));
  }

  // ── Terminal ──────────────────────────────────────────────────────────────

  runCommand(cmd: string) {
    const trimmed = cmd.trim();
    const output = [...this.state.terminalOutput, `user@raos:~$ ${trimmed}`];

    const addLines = (...lines: string[]) => output.push(...lines);

    const parts = trimmed.split(' ');
    const command = parts[0];
    const args = parts.slice(1);

    if (!trimmed) {
      // do nothing
    } else if (command === 'help') {
      addLines(
        'RaaOs Shell — available commands:',
        '  ls [path]       — list directory',
        '  cat [file]      — view file',
        '  pwd             — print working directory',
        '  cd [path]       — change directory',
        '  whoami          — current user',
        '  uname           — kernel info',
        '  ps              — process list',
        '  ifconfig        — network info',
        '  mail            — open mail client',
        '  irc             — open IRC client',
        '  notes           — open notes',
        '  fs              — open filesystem browser',
        '  clear           — clear terminal',
        '  uptime          — system uptime',
        '  free            — memory usage',
        '  df              — disk usage',
        '  date            — current date/time',
        '  echo [text]     — print text',
        '  ping [host]     — ping (loopback only)',
      );
    } else if (command === 'clear') {
      this.setState(() => ({ terminalOutput: [] }));
      this.setState(s => ({ terminalHistory: [...s.terminalHistory, trimmed] }));
      return;
    } else if (command === 'ls') {
      const path = args[0] || this.state.currentPath;
      if (path.includes('notes')) {
        addLines('total ' + this.state.notes.length);
        this.state.notes.forEach(n => addLines(`-rw-r--r-- 1 user user ${n.content.length.toString().padStart(6)} ${n.modified.split('T')[0]}  ${n.filename}`));
      } else if (path.includes('mail')) {
        addLines('inbox/  sent/  drafts/');
        addLines('inbox/new/:');
        this.state.emails.filter(e => e.folder === 'inbox/new').forEach(e => addLines(`  ${e.id}  "${e.subject}"`));
        addLines('inbox/cur/:');
        this.state.emails.filter(e => e.folder === 'inbox/cur').forEach(e => addLines(`  ${e.id}  "${e.subject}"`));
      } else if (path.includes('irc')) {
        addLines('mirc.ini  aliases.ini  users.ini');
        addLines('channels/:');
        Object.keys(this.state.ircMessages).forEach(ch => addLines(`  ${ch.slice(1)}.log`));
      } else if (path === '/sandbox/' || path === '/') {
        addLines('drwxr-xr-x  kernel/');
        addLines('drwxr-xr-x  fs/');
        addLines('drwxr-xr-x  bin/');
        addLines('drwxr-xr-x  state/');
      } else if (path.includes('/sandbox/fs') || path === 'fs') {
        addLines('drwxr-xr-x  notes/');
        addLines('drwxr-xr-x  mail/');
        addLines('drwxr-xr-x  irc/');
      } else {
        addLines(`ls: ${path}: No such file or directory`);
      }
    } else if (command === 'pwd') {
      addLines(this.state.currentPath);
    } else if (command === 'cd') {
      const target = args[0] || '/sandbox/';
      this.setState(() => ({ currentPath: target }));
      addLines();
    } else if (command === 'whoami') {
      addLines('user');
    } else if (command === 'uname') {
      addLines('RaaOs 1.0 raos-kernel #1 SMP loopback-only x86_64 GNU/RaaOs');
    } else if (command === 'ps') {
      addLines('PID   PPID  STAT  CMD');
      addLines('1     0     S     /sbin/init');
      addLines('2     1     S     kernel-sandbox');
      addLines('42    1     S     mail-daemon (loopback)');
      addLines('43    1     S     irc-daemon (loopback)');
      addLines('44    1     S     cow-layer');
      addLines('99    1     S     /bin/sh');
      addLines('100   99    R     ps');
    } else if (command === 'ifconfig') {
      addLines('lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>');
      addLines('     inet 127.0.0.1 netmask 0xff000000');
      addLines('     inet6 ::1 prefixlen 128');
      addLines('');
      addLines('[SANDBOX] External interfaces: DISABLED');
      addLines('[SANDBOX] Network policy: loopback-only');
    } else if (command === 'date') {
      addLines(new Date().toString());
    } else if (command === 'uptime') {
      addLines(`up ${Math.floor(Math.random() * 48) + 1}h, 1 user, load average: ${(Math.random() * 0.5).toFixed(2)}, ${(Math.random() * 0.3).toFixed(2)}, ${(Math.random() * 0.2).toFixed(2)}`);
    } else if (command === 'free') {
      addLines('              total        used        free');
      addLines(`Mem:         512000      ${Math.floor(this.state.memUsed * 5120)}      ${Math.floor((100 - this.state.memUsed) * 5120)}`);
      addLines('Swap:             0           0           0');
    } else if (command === 'df') {
      addLines('Filesystem      Size  Used Avail Use% Mounted on');
      addLines('/dev/sandbox     1G   64M  960M   7% /sandbox');
      addLines('cow-layer       256M   2M  254M   1% /sandbox/state');
    } else if (command === 'echo') {
      addLines(args.join(' '));
    } else if (command === 'ping') {
      const host = args[0] || 'localhost';
      if (host === 'localhost' || host === '127.0.0.1' || host.endsWith('.local')) {
        addLines(`PING ${host}: 56 data bytes`);
        for (let i = 0; i < 4; i++) addLines(`64 bytes from 127.0.0.1: icmp_seq=${i} ttl=64 time=${(Math.random() * 0.5).toFixed(3)} ms`);
        addLines(`--- ${host} ping statistics ---`);
        addLines('4 packets transmitted, 4 received, 0% packet loss');
      } else {
        addLines(`ping: ${host}: Network unreachable (sandbox: external network disabled)`);
      }
    } else if (command === 'cat') {
      const file = args[0];
      if (!file) { addLines('cat: missing operand'); }
      else if (file === 'mirc.ini' || file.includes('mirc.ini')) {
        const c = this.state.ircConfig;
        addLines('[mirc]');
        addLines(`nick=${c.nick}`);
        addLines(`server=${c.server}`);
        addLines(`autojoin=${c.autojoin.join(',')}`);
        addLines('');
        addLines('[options]');
        addLines(`logging=${c.logging ? 1 : 0}`);
        addLines(`timestamps=${c.timestamps ? 1 : 0}`);
      } else {
        const note = this.state.notes.find(n => n.filename === file);
        if (note) addLines(...note.content.split('\n'));
        else addLines(`cat: ${file}: No such file or directory`);
      }
    } else if (command === 'mail') {
      this.openApp('mail');
      addLines('[mail] Opening mail client...');
    } else if (command === 'irc') {
      this.openApp('irc');
      addLines('[irc] Opening IRC client...');
    } else if (command === 'notes') {
      this.openApp('notes');
      addLines('[notes] Opening notes...');
    } else if (command === 'fs') {
      this.openApp('fs');
      addLines('[fs] Opening filesystem browser...');
    } else {
      addLines(`${command}: command not found. Type 'help' for commands.`);
    }

    this.setState(s => ({
      terminalOutput: output,
      terminalHistory: [...s.terminalHistory, trimmed],
    }));
  }

  setBootComplete() {
    this.setState(() => ({ bootComplete: true }));
  }

  tickTime() {
    this.setState(() => ({
      systemTime: new Date().toISOString(),
      cpuLoad: Math.max(1, Math.min(99, this.state.cpuLoad + (Math.random() - 0.5) * 5)),
      memUsed: Math.max(10, Math.min(90, this.state.memUsed + (Math.random() - 0.5) * 2)),
    }));
  }
}

export const store = new OSStore();
export { generateId };
