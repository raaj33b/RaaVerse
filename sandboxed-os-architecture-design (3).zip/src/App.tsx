import { useState, useEffect, useCallback } from 'react';
import BootScreen from './components/BootScreen';
import Desktop from './components/Desktop';
import Taskbar from './components/Taskbar';
import TopBar from './components/TopBar';
import { store } from './store/osStore';

export default function App() {
  const [booted, setBooted] = useState(false);

  const handleBootDone = useCallback(() => {
    setBooted(true);
    // Open terminal by default after boot
    setTimeout(() => {
      store.openApp('terminal');
    }, 300);
  }, []);

  // Tick system clock & stats every second
  useEffect(() => {
    if (!booted) return;
    const t = setInterval(() => store.tickTime(), 1000);
    return () => clearInterval(t);
  }, [booted]);

  return (
    <div className="fixed inset-0 overflow-hidden bg-black font-mono">
      {/* Boot screen — covers everything */}
      {!booted && <BootScreen onDone={handleBootDone} />}

      {/* OS Desktop */}
      {booted && (
        <>
          <TopBar />
          <Desktop />
          <Taskbar />
        </>
      )}
    </div>
  );
}
