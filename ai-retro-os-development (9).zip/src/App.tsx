import React, { useState } from 'react';
import { Terminal, Folder, FileText, Cpu, Shield, Zap, Search, Settings, Wifi } from 'lucide-react';

type FileItem = { name: string; type: 'file' | 'folder'; size: string };

const initialFiles: FileItem[] = [
  { name: 'projects', type: 'folder', size: '-' },
  { name: 'thesis_draft.pdf', type: 'file', size: '12 MB' },
  { name: 'network_config.sys', type: 'file', size: '2 KB' },
  { name: 'ai_engine.bin', type: 'file', size: '450 MB' },
];

export function App() {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<string[]>(['Raaxplorer v2026.01.01', 'System Ready. Agentic LLM Core Online.']);
  const [files] = useState<FileItem[]>(initialFiles);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;
    setLogs((prev) => [...prev, `> ${input}`, `Processing "${input}"... [AI-AGENT] Executed successfully.`]);
    setInput('');
  };

  return (
    <div className="h-screen w-screen bg-black text-green-500 font-mono flex flex-col p-2 overflow-hidden selection:bg-green-900 selection:text-white">
      {/* Header */}
      <header className="border-b border-green-800 p-2 flex justify-between items-center text-sm">
        <div className="flex items-center gap-2 font-bold text-lg"><Terminal className="w-5 h-5"/> RAAXPLORER v2026</div>
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><Cpu className="w-4 h-4"/> 4% CPU</span>
          <span className="flex items-center gap-1"><Shield className="w-4 h-4 text-emerald-400"/> SECURE</span>
          <span className="flex items-center gap-1"><Wifi className="w-4 h-4"/> ONLINE</span>
        </div>
      </header>

      {/* Main Grid */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <nav className="w-48 border-r border-green-800 p-4 space-y-4">
          <div className="flex items-center gap-2 cursor-pointer hover:bg-green-900 p-1 rounded"><FileText className="w-4 h-4"/> Files</div>
          <div className="flex items-center gap-2 cursor-pointer hover:bg-green-900 p-1 rounded"><Zap className="w-4 h-4"/> AI Engine</div>
          <div className="flex items-center gap-2 cursor-pointer hover:bg-green-900 p-1 rounded"><Settings className="w-4 h-4"/> Security</div>
        </nav>

        {/* Content Area */}
        <main className="flex-1 p-4 flex flex-col gap-4">
          <div className="flex border border-green-800 rounded p-1">
            <Search className="w-6 h-6 m-1 opacity-50"/>
            <input className="bg-transparent flex-1 outline-none px-2" placeholder="Ask Raaxplorer to generate, search or analyze..."/>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {files.map((f) => (
              <div key={f.name} className="border border-green-900 p-4 flex flex-col items-center gap-2 hover:bg-green-950 transition-colors">
                {f.type === 'folder' ? <Folder className="w-12 h-12 text-green-600"/> : <FileText className="w-12 h-12"/>}
                <span className="text-xs text-center">{f.name}</span>
                <span className="text-[10px] opacity-50">{f.size}</span>
              </div>
            ))}
          </div>

          <div className="flex-1 border border-green-800 p-4 overflow-y-auto">
            {logs.map((log, i) => <p key={i} className="text-sm">{log}</p>)}
          </div>
        </main>
      </div>

      {/* Footer / CMD */}
      <form onSubmit={handleCommand} className="border-t border-green-800 flex items-center p-2">
        <span className="mr-2">RAA$</span>
        <input 
          value={input} 
          onChange={(e) => setInput(e.target.value)}
          className="bg-transparent flex-1 outline-none"
          placeholder="Enter shell command..."
        />
      </form>
    </div>
  );
}
